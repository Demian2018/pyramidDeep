from wsgiref.simple_server import make_server
from pyramid.config import Configurator

if __name__ == '__main__':
    config = Configurator()
    config.include('pyramid_jinja2')
    config.add_route('home', '/')
    config.add_route('edit', '/edit')
    config.add_route('insert', '/insert')
    config.add_route('thumbUp', '/thumbUp')
    config.add_route('thumbDown', '/thumbDown')
    config.add_route('score', '/score')
    #config.add_route('exception', '/problem')
    #css,etc..
    config.add_static_view(name='static', path='static')
    #views
    config.scan('views')
    #server
    app = config.make_wsgi_app()
    server = make_server('0.0.0.0', 1234, app)
    server.serve_forever()