import cgi

from pyramid.httpexceptions import HTTPFound
from pyramid.response import Response
from pyramid.view import view_config

from pyramid.config import Configurator
from urllib.parse import urlparse
#from gridfs import gridfs
from pymongo import MongoClient

#MongoDB Conn
try:
        conn = MongoClient()
        #print("Connected successfully!!!")
        # database
        db = conn.video1
        
        # Created or Switched to collection
        collection = db.formVideos1

except:  
        print("Could not connect to MongoDB")



######Views######

#/home
@view_config(route_name='home', renderer='jinja2/hello_world.jinja2')
def home_view(request):

    return dict(listaVideos=collection.find())


# /insert
@view_config(route_name='insert', renderer='jinja2/insert.jinja2')
def insert_view(request):
    if request.method == 'POST':
        emp_rec1 = {
                "video" :request.params['video'],
                "theme" :request.params['theme'],
                "yes"   :0,
                "no"    :0,
                "fScore":0
                }
        # Insert Data
        collection.insert_one(emp_rec1)
        return HTTPFound(location="/")
    
    return dict(empty="y")



#/thumbUp
@view_config(route_name='thumbUp')
def thumbUp_view(request):

    #update db, set thumbUp + 1
    resu = collection.find({'video': request.params['video']})
    for y in resu:
        #yes = y['yes'] + 1
        collection.replace_one(
            {"video":request.params['video']},
                {
                    "video" :request.params['video'],
                    "theme" :y['theme'],
                    "yes"   :y['yes'] + 1,
                    "no"    :y['no'],
                    "fScore": (y['yes'] + 1) - (y['no'] / 2)
                }
        )

    #return dict(resu=resu, aa = aa)
    return HTTPFound(location="/")


#/thumbDown
@view_config(route_name='thumbDown')
def thumbDown_view(request):

    #update db, set thumbDown + 1
    resu = collection.find({'video': request.params['video']})
    for y in resu:
        h = y['no'] + 1
        collection.replace_one(
            {"video":request.params['video']},
                {
                    "video"  :request.params['video'],
                    "theme"  :y['theme'],
                    "yes"  :y['yes'],
                    "no"  :y['no'] + 1,
                    "fScore": y['yes'] - ( h / 2 )
                }
        )

    return HTTPFound(location="/")


#/score
@view_config(route_name='score', renderer='jinja2/score.jinja2')
def score_view(request):
    #resu = collection.find({'video': request.params['video']})
    return dict(listaVideos=collection.find().sort([('fScore', -1)]))
